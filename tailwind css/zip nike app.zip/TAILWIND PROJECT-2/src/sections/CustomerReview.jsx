

const CustomerReview = () => {
  return (
    <div>
      heloo csr
    </div>
  )
}

export default CustomerReview
