

const Subscribe = () => {
  return (
    <div>
      hello subscribe
    </div>
  )
}

export default Subscribe
