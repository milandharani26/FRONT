import React from 'react'

const Footer = () => {
  return (
    <div className="text-white">
      hello footer
    </div>
  )
}

export default Footer
